#include <stdio.h>
int main( void )
{
	int *(ptr[5]);

	}
