#include<stdio.h>
 int a = 10;
int main(void)
{
	extern int b;
	b = 100;
//printf("%d",b)	;
}
