//#include <stdio.h>
int a;
int fun()
{
	a = 5;
	printf("a in another file = %d\n",a);
	return 0;
}
