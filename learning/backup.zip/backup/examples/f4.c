                            = 90
data3= 40
data12 = 76
data45 = 67
data5656565 = 12345
