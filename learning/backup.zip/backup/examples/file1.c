data1=10
data2=20 
