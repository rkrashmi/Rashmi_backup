#include <stdio.h>
#include <stdlib.h>
#define MAX 25

int choice;
char *buf = NULL;
int num;

int main(void)
{
//  int choice;
//  char *buf = NULL;

	if (NULL == (buf = (char *) malloc(sizeof(char) * 10))) {
		perror("Malloc failed\n");
		return EXIT_FAILURE;
	}
  L2:
	printf("****************......MENU......*********************\n");
	printf("1.Idli\n2.Dosa\n3.Rice\n4.snacks\n5.exit\n");

	if (NULL == fgets(buf, MAX, stdin)) {
		perror("fgets faield\n");
		return EXIT_FAILURE;
	}
	choice = atoi(buf);

	switch (choice) {

	case 1:{
		  L1:
			printf("----------------Options for idli are------------\n");
			printf("1.Idli vada\n2.Plane Idli\n3.Masala Idli\n4.exit\n");

			if (NULL == fgets(buf, MAX, stdin)) {
				perror("fgets failed\n");
				return EXIT_FAILURE;
			}
			choice = atoi(buf);

			switch (choice) {
			case 1:
				printf("---- Price = %d\n", 45);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 20, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L1;
					else
						goto L2;
				}
				break;


			case 2:
				printf("-----Price = %d\n", 30);
				printf("-----Time required for preperation is = %0d:%d:%0d\n", 0, 15, 0);
				printf("\n");
				printf("--------------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);

				if (num == 1) {
					printf("\n");
					sleep(5);
					printf("Your Order is Confirmed    :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					//  printf("Please Enter valid Input\n");
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L1;
					else
						goto L2;

				}
				break;

			case 3:
				printf("-----Price = %d\n", 50);
				printf("-----Time required for preperation is = %d:%d:%d\n", 0, 25, 0);
				printf("\n");
				printf("---------------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);

				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed    :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					//  printf("Please Enter valid Input\n");
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L1;
					else
						goto L2;
				}
				break;
			case 4:
				return EXIT_SUCCESS;
			default:
				printf("Please enter the valid option\n");
				break;
			}

		}
		break;


	case 2:{
		  L3:
			printf("----------------Options for dosa are------------\n");
			printf("1.set dosa\n2.Plane dosa\n3.Masala dosa\n4.Butter Masala dosa\n5.exit\n");

			if (NULL == fgets(buf, MAX, stdin)) {
				perror("fgets failed\n");
				return EXIT_FAILURE;
			}
			choice = atoi(buf);

			switch (choice) {
			case 1:
				printf("---- Price = %d\n", 45);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 20, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L3;
					else
						goto L2;
				}
//                  printf("Please Enter valid Input\n");
				break;

			case 2:
				printf("---- Price = %d\n", 40);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 15, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L3;
					else
						goto L2;
				}
				//  printf("Please Enter valid Input\n");
				break;

			case 3:
				printf("---- Price = %d\n", 50);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 30, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L3;
					else
						goto L2;
				}
//                  printf("Please Enter valid Input\n");
				break;

			case 4:
				printf("---- Price = %d\n", 60);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 30, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L3;
					else
						goto L2;
				}
				//              printf("Please Enter valid Input\n");
				break;
			case 5:
				return EXIT_SUCCESS;

			default:
				printf("Please enter valid option\n");
			}
		}

		break;

	case 3:{
		  L4:
			printf("----------------Options for Rice are------------\n");
			printf
				("1.Ghee rice\n2.Jeera rice\n3.Masala Bhaat\n4.bisibele Bhaat\n5.Veg biriyaani\n6.curd rice\n7.exit\n");

			if (NULL == fgets(buf, MAX, stdin)) {
				perror("fgets failed\n");
				return EXIT_FAILURE;
			}
			choice = atoi(buf);

			switch (choice) {


			case 1:
				printf("---- Price = %d\n", 90);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 45, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L4;
					else
						goto L2;
				}
				//  printf("Please Enter valid Input\n");
				break;

			case 2:
				printf("---- Price = %d\n", 90);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 45, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L4;
					else
						goto L2;
				}
				//  printf("Please Enter valid Input\n");
				break;

			case 3:
				printf("---- Price = %d\n", 100);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 50, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L4;
					else
						goto L2;
				}
//                  printf("Please Enter valid Input\n");
				break;

			case 4:
				printf("---- Price = %d\n", 70);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 30, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					//      printf("Please Enter valid Input\n");
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L4;
					else
						goto L2;
				}
				break;

			case 5:
				printf("---- Price = %d\n", 120);
				printf("---- Time required for preperation is = %d:%d:%d\n", 1, 0, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L4;
					else
						goto L2;
				}

//                  printf("Please Enter valid Input\n");
				break;
			case 6:
				printf("---- Price = %d\n", 50);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 10, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					//  printf("Please Enter valid Input\n");
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L4;
					else
						goto L2;
				}
				break;
			case 7:
				return EXIT_SUCCESS;
			default:
				printf("please enter valid option");
				break;
			}
		}

		break;


	case 4:{
		  L5:
			printf("----------------Options for snacks are------------\n");
			printf
				("1.Pani puri\n2.Bhel puri\n3.Masala puri\n4.Sev puri\n5.Pav Bhaji\n6.alu tikka\n7.exit\n");

			if (NULL == fgets(buf, MAX, stdin)) {
				perror("fgets failed\n");
				return EXIT_FAILURE;
			}
			choice = atoi(buf);

			switch (choice) {

			case 1:
				printf("---- Price = %d\n", 20);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 10, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;

				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L5;
					else
						goto L2;
				}
				//              printf("Please Enter valid Input\n");
				break;

			case 2:
				printf("---- Price = %d\n", 25);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 15, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L5;
					else
						goto L2;
				}
				//  printf("Please Enter valid Input\n");
				break;
			case 3:
				printf("---- Price = %d\n", 35);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 20, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L5;
					else
						goto L2;

//                  printf("Please Enter valid Input\n");
				}
				break;

			case 4:
				printf("---- Price = %d\n", 35);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 15, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L5;
					else
						goto L2;
				}

//                  printf("Please Enter valid Input\n");
				break;

			case 5:
				printf("---- Price = %d\n", 50);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 15, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L5;
					else
						goto L2;
				}
				//  printf("Please Enter valid Input\n");
				break;

			case 6:
				printf("---- Price = %d\n", 35);
				printf("---- Time required for preperation is = %d:%d:%d\n", 0, 15, 0);
				printf("\n");
				printf("----------If you want to confirm Order : Press 1\n");

				if (NULL == fgets(buf, MAX, stdin)) {
					perror("fgets failed\n");
					return EXIT_FAILURE;
				}
				num = atoi(buf);


				if (num == 1) {
					printf("\n");
					sleep(5);

					printf("Your Order is Confirmed   :)\n");
					printf("Please wait\n");
					goto L2;
				} else {
					printf("Want to order something else? \n");
					printf("Y/N\n");

					if (NULL == fgets(buf, MAX, stdin)) {
						perror("fgets failed\n");
						return EXIT_FAILURE;
					}
					if (*buf == 'y')
						goto L5;
					else
						goto L2;
				}
				//  printf("Please Enter valid Input\n");
				break;
			case 7:
				return EXIT_SUCCESS;

			default:
				printf("please enter valid option\n");
			}
		}

		break;


	case 5:
		return EXIT_SUCCESS;
	default:
		printf("Please enter valid Option\n");
		break;

	}

	return 0;
}
