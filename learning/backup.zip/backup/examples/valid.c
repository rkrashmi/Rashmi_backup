#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 255
int flag;
int main(int argc, char *argv[])
{
	int c;
	int index = 0;
	int count = 0;
	char *buf = NULL;
	FILE *fp;
	FILE *fp1;

	if (NULL == (fp = fopen(*++argv, "r"))) {
		perror("open failed\n");
		return EXIT_FAILURE;
	}

	if (NULL == (fp1 = fopen(*++argv, "a+"))) {
		perror(" file open failed\n");
		return EXIT_FAILURE;
	}

	if (NULL == (buf = (char *) malloc(sizeof(char) * MAX))) {
		perror("malloc failed\n");
		return EXIT_FAILURE;
	}
	while (c != EOF) {
		flag = 1;
		while ((c = fgetc(fp)) != EOF) {

//for copying name
			#if 0
			if(c == 32){
				*(buf + index) = c;
				while((c = fgetc(fp)) == 32);
				
				break;
				}
			#endif	
		
			 if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122) || (c >= 48 && c <= 57 || c == 32)) {
				*(buf + index) = (char) c;
				index++;
				
			} else if (c == 61) {
				*(buf + index) = c;
				index++;
				printf(" buf = %s\n",buf);
				printf("%c\n",c);
				break;
			} else {
				memset(buf, '\0', MAX);
			//	bzero(buf, sizeof(buf));
				while ((c = fgetc(fp)) != '\n');
				if (c == '\n') {
					*(buf + index) = '\n';
					index = 0;
				}
			}
	
		}

		if (flag = 1) {
			while ((c = fgetc(fp)) != EOF) {
//for copying value
				if (c >= 48 && c <= 57) {
					*(buf + index) = c;
					index++;

				} else if (c == 32) {
					*(buf + index) = c;
					index++;
		
				} else if (c == '\n') {
					*(buf + index) = '\n';
					break;
				} else {
					memset(buf, '\0', MAX);
				//	bzero(buf,sizeof(buf));
					while ((c = fgetc(fp)) != '\n');
					if (c == '\n') {
						*(buf + index) = '\n';
						index = 0;
					}
					flag = 0;
					break;
				}
			}
		}
		fputs(buf, fp1);
		index = 0;

	}
	close(fp);
	close(fp1);

	return 0;
}
