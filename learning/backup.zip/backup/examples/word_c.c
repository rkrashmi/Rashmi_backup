#include <stdio.h>
#include <stdlib.h>

int main( void )
{
	int word_count = 0;
	int line_count = 0;
	int char_count = 0;
//	int state = 0;
	int c;


	while((c = getchar()) != EOF){
		char_count++;
		
		if(c == '\n'){
			line_count++;
		}
	
		if(c == ' ' || c == '\n' || c == '\t'){
//			state = 0;
//		}
//		else if(state == 0){
//			state = 1;
			word_count++;
		}
	}
	printf("wc = %d\nLn = %d\nCc = %d\n",word_count,line_count,char_count);

	return 0;
}
