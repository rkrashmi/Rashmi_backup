#include<stdio.h>
const int a = 10;
int main()
{
	printf("%d\n",a);
	return 0;
}
