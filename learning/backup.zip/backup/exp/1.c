#include <stdio.h>

struct A{
	char a;
	int b;
	};

int main()
{
	struct A a;
	printf("size = %d\n",sizeof(a));
	return 0;
}
