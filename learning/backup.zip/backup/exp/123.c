#include <stdio.h>
int main( void )
{
	printf("%s\n",NULL);

	return 0;
}
