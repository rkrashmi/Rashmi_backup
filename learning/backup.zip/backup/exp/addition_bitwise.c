#include <stdio.h>
#include <stdio_ext.h>


// addition of two numbers using bitwise operators

int main(void)
{
int num ,num1, num2, sum, carry = 0, Max_bits = 7, bits = 0;    //num1, num2 are 2 numbers
	

	printf("Enter two numbers\n");
	__fpurge(stdout);
	scanf("%d%d",&num1,&num2);
//	printf("%d%d",num1,num2);

	while(bits != Max_bits)
		{
//		printf("enter the loop\n");
		if( (((num1 & 1 ) == 1) &((num2 & 1 ) == 1) & (carry == 0)  ) ||
			(((num1 & 1 ) == 1) &((num2 & 1 ) == 1) & (carry == 0)  ) ||		
		    (((num1 & 1 ) == 1) &((num2 & 1 ) == 1) & (carry == 0)  ) ||
			(((num1 & 1 ) == 1) &((num2 & 1 ) == 1) & (carry == 0)  ) )    // checking the condition to generate carry 
		{
		sum = (num1 & 1) ^ (num2 & 1) ^ carry;                            //addition operation
		num1 = num1 >> 1;                                                 // to add next bits of 2 numbers
		num2 = num2 >> 2;                                                
		sum = sum | (sum << bits);                                          //moving the sum bits
		carry = 1;                                                       //generate carry for next addition
		}
		
		else
		{
		sum = (num1 & 1) ^ (num2 & 1);                                  //addition without carry
		sum = sum | (sum << bits);
		carry = 0;                                                      //carry is made 0 if not generated
		}		
		bits++;                                                        //inorder to move to the next bit addition
		}
 
      //inorder to represent the number with carry as a decimal no.

		while(!(sum & (1 << Max_bits)))
			{
				Max_bits--;
		    }
		carry = carry << (Max_bits + 1);
		sum = sum | carry;
		printf("Addition of two numbers %d and %d is %d\n", num1, num2, sum);
	
		return 0;

}
