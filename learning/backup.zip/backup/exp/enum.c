#include<stdio.h>
enum alpha{A = 1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z};

int main()
{
	int i;
	int j;
	enum alpha a;
	char ch[10];
	printf("Enter the string:\n");
	scanf("%d\n",&ch[10]);

	for(i = 0; i <  
