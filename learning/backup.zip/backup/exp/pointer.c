#include <stdio.h>
#include <stdlib.h>
int * fun(int *p)
{
	*p = 70;
	printf("%p\n",p);
	free(p);

}

int main (void )
{
	int *p = malloc(20);
	*p = 50;
//	p++;
	fun(p);
	*p = 60;
	printf("%d\n",*p);
	free(p);
	return 0;
}
