#include <stdio.h>

struct A
        {
                int a;
                int b;
                int c [];
        };


int main (void)
{

/*	struct A
	{	
		int a;
		int b;
		char c [];
	};
*/
	struct A b1,b2,b3;

	printf("size of struct A %d\n", (int)sizeof(struct A));
	printf("b1 %d\n", (int)sizeof(b1));
	printf("b2 %d\n", (int)sizeof(b2));
	
	b1.a = 1;
	b1.b = 2;

	b2.a = 3;
	b2.b = 4;

	b3.a = 5;
	b3.b = 6;

	b1.c[0] = 21;
//	b1.c[1] = 22;
	b1.c[2] = 23;
	b1.c[3] = 24;
	b1.c[4] = 25;
//	b1.c[5] = 26;
//	b1.c[6] = 27;
//	b1.c[7] = 28;

	printf("b1 after flexing %d\n", (int)sizeof(b1));
	printf("b2 after flexing %d\n", (int)sizeof(b2));

	printf("%d\n%d\n%d\n%d\n",b2.a,b2.b,b1.a, b1.b);

	return 0;
}
