#include<stdio.h>
#include <stdlib.h>

int main(void)
{
 printf("enyer the input\n");

char *buf=NULL;
char *buf1=NULL;
buf = (char *)malloc(sizeof(char) * 20);
buf1 = (char *)malloc(sizeof(char ) * 20);

fgets(buf ,20,stdin);
fgets(buf1,20,stdin);
printf("%s",buf);
printf("%s",buf1);
}
