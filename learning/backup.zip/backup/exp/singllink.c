#include <stdio.h>
#include<stdlib.h>
#define MAX 256

struct node{

	int data;
	struct node * link;
};

int main( void )
{
	
	struct node * head = NULL;
	struct node * temp = NULL;
	struct node * new = NULL;
	struct node * prev = NULL;

	int index;
	int n;
	int pos;
	int count;
	int choice;
	char * ptr = NULL;

	count = 0;
	ptr = (char *)malloc(sizeof(char) * MAX);
	
	printf("enter number of nodes\n");
	fgets(ptr, MAX, stdin);
	n = atoi ( ptr );

	while ( 1 ){
	printf("enter the choice 1. insert node\n 2. display node\n 3. insert node at the first\n 4. insert node at the last\n 5.insert node at given position\n 6. insert node before the given position\n 7. insert after the given position\n 8. insert node at the middle\n 9. delete first node in the list\n 10. last node deletion\n 11. exit\n");
	fgets ( ptr, MAX , stdin);
	choice = atoi ( ptr );
	*ptr = count;
	//while ( 1 ){
	
	switch ( choice ){
	
	case 1: printf("nodes creation\n");
						
			for ( index = 0 ; index < n ; index++){
	
			if ( head == NULL){
			
			printf("list is empty\n");		
	
			printf("enter elements for nodes\n");

			new = (struct node *) malloc ( sizeof ( struct node ));

			head = new;
	
			new -> data = atoi(fgets(ptr, MAX, stdin));

			new -> link = NULL;
			
			*ptr++;

			} else {

//			printf(" list is not empty\n");

			temp = head;
		
			while( temp -> link != NULL ){

				temp = temp -> link;
			}

			new = (struct node *) malloc ( sizeof ( struct node));

			temp -> link = new;
	
			new -> link = NULL;

			new -> data = atoi(fgets( ptr, MAX, stdin) );
    
     		*ptr++;

			}
			}
			
			break;

	case 2: printf("displaying list\n");

			temp = head;

//			for ( index = 0 ; index < n ; index++){

//			if ( temp != NULL){
			if ( temp == NULL){

			printf("empty list\n");

			} else {

			printf("elements in list are\n");	

			while ( temp  != NULL){

			printf(" %d\n", temp -> data);
	
			temp = temp -> link;

			}
			} 
			

			break;
	
	case 3: printf("inserting node at the first\n");
	
			new = (struct node *) malloc ( sizeof(struct node ));

			new -> link = head;

			head = new;

			printf("enter data to be inserted at the first new node\n");
		
			fgets( ptr, MAX, stdin);

			new -> data = atoi ( ptr );
	
			*ptr++;
		
			break;

	case 4: printf("inserting node at the last\n");

			new = (struct node *) malloc ( sizeof(struct node) );

			printf("enter element for the last node\n");
			
			fgets( ptr, MAX, stdin);

			temp = head;

			if( head == NULL ){
		
				head = new;
				new -> data = atoi( ptr );
				new -> link = NULL;
			} else {

			while ( temp -> link != NULL ){

				temp = temp -> link;
			}

			temp -> link = new;

			new -> link = NULL;

//			new -> data = atoi( ptr );

//			*ptr++;
			}
	
			break;

	case 5:	prev = head;
			temp = head;

			count = 0;
		
			printf("enter the position at which node is to be inserted\n");

			fgets(ptr, MAX, stdin);

			pos = atoi( ptr);

			pos = pos - 1;
	
			if ( pos <=0 || pos > n ){

			printf("invalid position\n");
			exit( 0 );
		
			}

			printf("enter data to be entered in the inserted node\n");
	
			fgets( ptr, MAX , stdin );

			while ( temp != NULL ){
			
			
			if ( count == pos ){

			new = (struct node *) malloc ( sizeof(struct node) ) ;

			prev -> link = new;

			new -> link = temp;

	
//			printf("enter data to be entered in the inserted node\n");
	
//			fgets( ptr, MAX , stdin );

			new -> data = atoi( ptr ); 
			
			} 
		
				count++;
				prev = temp;
				temp = temp -> link;

			}

			break;

	case 6: printf("inserting node before the given position\n");
		
			prev = head;
			temp = head;
	
			count = 0;
		
			printf("enter the position for the  node is to be inserted\n");

			fgets(ptr, MAX, stdin);

			pos = atoi( ptr);

			pos = pos - 1;
	
			printf("pos %d\n", pos);
		
			if ( pos < 0 ||  pos > n ){

			printf(" invalid position\n");
			exit ( 0 );

			}

			printf("enter data to be entered in the inserted node\n");
	
			fgets( ptr, MAX , stdin );
	
			if ( pos == 0){
			
			new = (struct node *) malloc ( sizeof(struct node));

			new -> link = head;
	
			head = new;
		
			new -> data = atoi ( ptr );
			}
	
			if ( pos > 0){
			for( index = 0 ; index < n ; index++){

				 if ( temp -> link != NULL ){
			
				 if ( count == pos ){

					new = (struct node *) malloc ( sizeof(struct node) ) ;

					prev -> link = new;

					new -> link = temp ;
			
					new -> data = atoi( ptr ); 
			
				}
			
			 
					
				count++;
				prev = temp;
				temp = temp -> link;

			}
		}
			}
	
			break;

	case 7: printf("inserting node after the given position\n");

    //        prev = head;
            temp = head;

            count = 0;

            printf("enter the position for the  node is to be inserted\n");

            fgets(ptr, MAX, stdin);

            pos = atoi( ptr);

      //      pos = pos + 1;

            if ( pos < 0 && pos > n ){

            printf(" invalid position\n");

            }

            printf("enter data to be entered in the inserted node\n");

            fgets( ptr, MAX , stdin );

//            for( index = 0 ; index < n ; index++){

                 while ( temp -> link != NULL ){

                 if ( count == pos ){

                    new = (struct node *) malloc ( sizeof(struct node) ) ;

//                    prev -> link = new;
	
					new -> link = temp -> link;

					temp -> link = new;

//					new -> link = temp;

                    new -> data = atoi( ptr );

                }



                count++;
  //              prev = temp;
                temp = temp -> link;

            }
        


            break;




	case 8: printf("inserting at the middle\n");	
			
			temp = head;
			prev = head;
			count = 0;

			while( temp -> link  != NULL){
					
				temp = temp -> link;
				count++;
//				prev = temp -> link -> link;

			}
			
			count /= 2;
		
			temp = head;

			for ( index = 0; index < n ; index++){
		
				if ( index == count){
					if( temp != NULL){
	
					new = (struct node *) malloc (sizeof(struct node));
			
					prev -> link = new;

					new -> link = temp;

					new -> data = atoi( fgets ( ptr, MAX, stdin));
				}
				}
	
					prev = temp;
					temp = temp -> link;
			}
			
			break;
		
	
	case 9: printf("first node deletion\n");
		
			temp = head;

			if( head == NULL){
			printf("no list\n");
			}
			
			else{
	
			head = temp -> link;
	
			free( temp );
			}
			break;
		
	
	case 10:printf("last node deletion\n");
			temp = head;
		//	prev = head;

			if ( temp == NULL){

			printf("NO LIST\n");
			exit( 0 );

			}
			else{

			while( temp -> link != NULL){
				
				prev = temp;
				temp = temp -> link;
				
			}
		
			prev -> link = NULL;

			free ( temp );
			}
		
			break;
			

	case 11: printf("deletion of list\n");

			 temp = head; 

			 if( head == NULL){

				printf("list is empty\n");	
			} else {

				while ( temp  != NULL){
				
					head = head -> link;
					free (temp);
					temp = head;
				}
			}
				
			break;
	
	case 12: printf("delete at the middle\n");
			
			 temp = head;
			 prev = head;
			 count = 0;

			 if ( head == NULL){

				printf(" list empty\n");

			 } else{
			 while( temp -> link != NULL){

				temp = temp -> link;
				count++;
			}
			}
				count /= 2;
				
			temp = head;
			
	//		for ( index = 0 ; index < n ; index++){
					if (temp -> link   != NULL){
						if ( index == count ){
						prev -> link = temp -> link;
						free(temp);
					}
					
					prev = temp;
					temp = temp -> link;
		
			}
			
			break;


	case 13: printf("deletion at the given position\n");
			 
			 temp = head;
			 prev = head;

			 for ( index = 0 ; index < n ; index++){
				if ( temp == NULL){
				
					printf("no list\n");
				} else {
				
					while( temp -> link = NULL){
						if( index == pos ){
					
						prev  -> link = temp -> link;

						free( temp );
						}
					
						prev = temp;
						temp = temp -> link;
				}
			}
			}
			break;
		
	case 14: printf("deletion of node before given position\n");		
			 
			 printf("enter the position before which node is to be deleted\n");
			 fgets( ptr, MAX, stdin);
			 pos = atoi( ptr );
			 temp = head;
			 prev = temp;
			 count = 0;

			 pos = pos - 1;

			 if ( head == NULL ){

				printf("no list to delete\n");

			 }  else if( head -> link == NULL ){

				free( head );

			 } else if( pos < 0 || pos > n ){

				printf("invalid position\n");

			 } else if ( pos == 0 && count > 1 ){ 

				head = temp -> link;

			 	free( temp );

			 } else {
				
				while( temp -> link != NULL ){
					if( pos == count ){
						prev -> link = temp -> link;
						free( temp );
					}
						prev = temp;
						temp = temp -> link;
						count++;
				}
			 }
			
			 break;		
						
				
	case 15: exit( 0 );
			break;


	default: printf("invalid input\n");

			break;

};

}
	return 0;
}
