#include <stdio.h>
#include <string.h>
int main( void )
{
	printf("%d\n",strlen("h"));
	return 0;
}
