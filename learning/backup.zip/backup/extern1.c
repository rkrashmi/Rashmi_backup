extern int g_var;

void fun(void)
{
	printf("%p\n",ptr);
	
}
