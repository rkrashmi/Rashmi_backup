#include<stdio.h>

int a = 10;

int main()
{
	printf("%d\n",a);
	return 0;
}
