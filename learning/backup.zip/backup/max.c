#include <stdio.h>

int main( void )
{
	int a = 10;
	int b = 20;

	( a > b && printf("a is greater") ||
