#include <stdio.h>
int a = 100;
int main( void )
{
	if(a > -1)
		printf("hi\n");
	else
		printf("hello\n");
	return 0;
}
