#include<stdio.h>

int main()

#if 0
{

	int a;
	printf("enter a\n");
	scanf("%d", &a);

	switch(a){
	
	case 1: printf("dhsfbsbfh\n");
			break;

	case 2:	printf("vghsdvhds\n");
			break;
	
	default: printf("invalid input\n");
			break;
	}

	return 0;
}
#endif
#if 0
{
	int j = 0;
	int i;

	for( i = 0 ; i < 100 ; i++)
	{
		j = ++j;
	}

	printf("j = %d\n",j);

	return 0;
}
#endif

#if 1

{
	printf("Hello");
	return 0;
}
#endif	
