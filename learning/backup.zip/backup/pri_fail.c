#include <stdio.h>

int main(void)
#if 0
{

	int a;
//	int *ptr = &a;	

	printf("%d\n",scanf("%d",&a));
//	printf("%n",hello);
	return 0;
}
#endif

#if 1
{
	int i,j;
	
	printf("hello%nhhjjhhjnnnmmmm%n", &i,&j);
	
	printf("%d %d", i,j);
	
	return 0;
}
#endif
