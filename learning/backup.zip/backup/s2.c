#include <stdio.h>
void fun(int *b)
{
//    int *ptr = NULL;

  //  ptr = &b;
    printf("ptr  = %d\n", *b);

}

