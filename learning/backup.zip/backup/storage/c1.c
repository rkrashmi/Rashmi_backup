#include <stdio.h>
static const int a = 7; 
//const int a = 43;
//int a;
int main(void)
{
	{
	static const int a = 3;
	//a = 4;
	printf("a = %d\n",a);
	}


printf("a = %d\n",a);
}
