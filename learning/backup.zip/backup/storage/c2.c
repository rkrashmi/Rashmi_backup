#include <stdio.h>

const int a = 4;
static const int b;
static int c;
const int d;
//static const int b = 10;

int main(void)
{
    return 0;
}

