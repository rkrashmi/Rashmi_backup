#include <stdio.h>

int a = 10;

int main( void )
{
/*	 int a = 33333;
	{
	    int a = 23;
		printf("within block = %d\n", a);
	}
	
	printf("outside block = %d\n",a);

	{
		extern int a;
		printf("a = %d\n", a);
	}

	return 0;
}
*/

	int a = 10;
	{
	
		extern int a;
		{
			extern int a;
			{
				int a = 40;
				printf(" a = %d\n",a);
			}
			
			printf(" a = %d\n", a);
		}
		printf(" a = %d\n",a);
	}
	printf(" a = %d\n",a);

}
	
