#include <stdio.h>
const int a = 10;

int main( void )
{
	int *ptr = &a;
	 *ptr = 20;

	printf("a = %d\n", *ptr);
	return 0;
}
