#include <stdio.h>
#include <stdlib.h>

int main()
{
kjdvhcjlsdbhcjkndk;cjw
jhcbjdbcdbn
jkiocjkjnx
kjdckjiodjcgfeywghfuihf
mknidh'jo'	we
jhd
}
