#include <stdio.h>

extern int a;

int main ( void )
{
    int a = 20;
	printf("a in main = %d",a);
	return 0;
}
