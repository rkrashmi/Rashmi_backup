#include <stdio.h>
#include <stdlib.h>

int a = 20;
int fun();
int fun();
int fun();
int fun();
 
int main( void )
{
	int a = 10;
	printf("a = %d\n",a);
//	fun();
	printf("a after calling fun = %d\n",fun());	
	return 0;
}	
