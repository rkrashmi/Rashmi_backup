#include <stdio.h>
extern int a;
int a;
//int a;
//int a;
int fun(void)
{
//	int a;
	printf("a in fun=%d\n",a);
	a++;
	return a;
}
