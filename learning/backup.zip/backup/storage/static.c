#include <stdio.h>
#include <stdlib.h>

int a = 20;

int fun( void);

int main( void )
{
//	static int a = 38;
	printf(" a in main = %d\n",a);
	
	int *p = fun();
	printf("a after calling = %d\n",*p);
	printf("a after calling = %p\n",p);
	int * ptr = fun();
	printf("a after calling = %d\n",*ptr);
    printf("a after calling = %p\n",ptr);

	

	{
		extern int a ;
		printf(" a in block = %d\n", a);
	}

	{
		static int b = 3;
		printf("b in block 2 = %d\n",b);
	}
	printf(" a = %d\n",*p);
	
	return 0;
}
