#include <stdio.h>
//int a;
int fun()
{
	int a = 99;
	printf("a in fun = %d\n",a);
	printf("a in fun = %p\n",&a);
	a++;
	return &a;
}
