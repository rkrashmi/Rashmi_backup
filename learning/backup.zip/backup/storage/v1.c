#include <stdio.h>

volatile int a;

