#include <stdio.h>
static const volatile int a = 20;

int main(void)
{
	printf("a = %d\n",a);
//	a++;
	printf("a = %d\n",a);
}
