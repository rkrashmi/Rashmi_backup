#include <stdio.h>

int main(int argc, char *argv[])
{
	int c;
	FILE *fp;
	char *str = 
	
	fp = fopen(* ++argv, "r");
	
	while( (c = getc(fp)) != EOF) {
		
			printf("%d\n", c);
		
			printf("\n\n");
	} 
	
	return 0;
}
