#include<stdio.h>

int main()
{
//	int a, b, c;
int d;
//	a = 20;
//	b = 9;

//	c = a == b;
	d = 32;
	printf("%d\n", sizeof(!d));
	printf("pid = %d", getpid());
	getchar();
	
	return 0;

}
